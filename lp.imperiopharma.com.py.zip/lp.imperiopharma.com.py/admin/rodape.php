<?php
// rodape.php
//
// Fecha o <main> aberto em cabecalho.php e insere o footer do painel.
// Lembre de que o CSS "painel.css" deve conter as classes utilizadas abaixo.
//
?>
  </main> <!-- /.painel-main -->
</div>   <!-- /.painel-layout -->

<footer class="painel-footer">
  <p>&copy; <?php echo date('Y'); ?> - Painel Administrativo Império Pharma</p>
</footer>

</body>
</html>
